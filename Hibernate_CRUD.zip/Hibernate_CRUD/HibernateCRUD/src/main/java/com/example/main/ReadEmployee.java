package com.example.main;

import com.example.model.Employee;
import com.example.util.HibernateUtil;
import org.hibernate.Session;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReadEmployee {
    private JTextField employeeIdField;
    private JButton readButton;
    private JTextArea resultArea;

    public ReadEmployee() {
        // Create JFrame
        JFrame frame = new JFrame("Read Employee");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        frame.setLayout(null);

        // Create field and label for employee ID
        JLabel employeeIdLabel = new JLabel("Employee ID:");
        employeeIdLabel.setBounds(10, 20, 80, 25);
        frame.add(employeeIdLabel);

        employeeIdField = new JTextField();
        employeeIdField.setBounds(100, 20, 165, 25);
        frame.add(employeeIdField);

        // Create read button
        readButton = new JButton("Read");
        readButton.setBounds(10, 60, 255, 25);
        frame.add(readButton);

        // Create text area to display the result
        resultArea = new JTextArea();
        resultArea.setBounds(10, 100, 255, 150);
        resultArea.setEditable(false);
        frame.add(resultArea);

        // Add action listener to the button
        readButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                readEmployee();
            }
        });

        // Set frame visibility
        frame.setVisible(true);
    }

    private void readEmployee() {
        Session session = HibernateUtil.getSessionFactory().openSession();

        try {
            // Retrieve employee based on ID
            int employeeId = Integer.parseInt(employeeIdField.getText());
            Employee employee = session.get(Employee.class, employeeId);
            
            // Display the employee's details
            if (employee != null) {
                String result = "Name: " + employee.getFirstName() + " " + employee.getLastName() + "\n"
                        + "Email: " + employee.getEmail();
                resultArea.setText(result);
            } else {
                resultArea.setText("Employee not found!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultArea.setText("Error retrieving employee: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    public static void main(String[] args) {
        new ReadEmployee();
    }
}
